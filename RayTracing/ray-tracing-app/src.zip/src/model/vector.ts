export class Vector {
    // x: number;
    // y: number;
    // z: number;
}